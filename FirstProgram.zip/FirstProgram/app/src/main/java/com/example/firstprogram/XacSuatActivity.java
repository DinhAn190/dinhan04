package com.example.firstprogram;

import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class XacSuatActivity extends AppCompatActivity {

    TextView txtNumber;
    ImageView imgDice;
    Button btnRandom;
    Random random = new Random();

    int[] diceFaces = {
            R.drawable.dice_1,
            R.drawable.dice_2,
            R.drawable.dice_3,
            R.drawable.dice_4,
            R.drawable.dice_5,
            R.drawable.dice_6
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_xac_suat);

        txtNumber = findViewById(R.id.txtNumber);
        imgDice = findViewById(R.id.imgdice);
        btnRandom = findViewById(R.id.btnRandom);

        btnRandom.setOnClickListener(v -> tungXucXac());
    }

    private void tungXucXac() {
        // 🔁 Tải animation xoay xúc xắc
        Animation shake = AnimationUtils.loadAnimation(this, R.anim.shake_dice);
        imgDice.startAnimation(shake);

        // 🔄 Hiển thị xúc xắc ngẫu nhiên liên tục trong 3 giây
        Handler handler = new Handler();
        final int duration = 3000; // 3 giây
        final int interval = 100;  // đổi mặt mỗi 0.1 giây
        final long startTime = System.currentTimeMillis();

        Runnable updateDice = new Runnable() {
            @Override
            public void run() {
                if (System.currentTimeMillis() - startTime < duration) {
                    int randomFace = random.nextInt(6);
                    imgDice.setImageResource(diceFaces[randomFace]);
                    handler.postDelayed(this, interval);
                } else {
                    // Dừng animation và hiển thị kết quả cuối
                    imgDice.clearAnimation();
                    int so = random.nextInt(6) + 1;
                    txtNumber.setText(String.valueOf(so));
                    imgDice.setImageResource(diceFaces[so - 1]);
                }
            }
        };
        handler.post(updateDice);
    }
}
