package com.example.firstprogram;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.*;

public class MainActivity extends AppCompatActivity {

    Button btnCamera, btnOpenCalculator, btnOpenXacSuat, btnOpenCallSms;
    ImageView imgPhoto;
    ActivityResultLauncher<Intent> cameraLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnCamera = findViewById(R.id.btnCamera);
        btnOpenCalculator = findViewById(R.id.btnOpenCalculator);
        btnOpenXacSuat = findViewById(R.id.btnOpenXacSuat);
        btnOpenCallSms = findViewById(R.id.btnOpenCallSms);
        imgPhoto = findViewById(R.id.imgPhoto);

        setupCameraLauncher();
        requestCameraPermission();

        // ✅ Bấm mở camera
        btnCamera.setOnClickListener(v -> {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cameraLauncher.launch(intent); // 🚀 ép mở luôn
        });

        // Các nút khác
        btnOpenCalculator.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, CalculatorActivity.class));
        });

        btnOpenXacSuat.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, XacSuatActivity.class));
        });

        btnOpenCallSms.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, CallSmsActivity.class));
        });
    }

    private void requestCameraPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CAMERA}, 100);
        }
    }

    private void setupCameraLauncher() {
        cameraLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        Bundle extras = result.getData().getExtras();
                        Bitmap imageBitmap = (Bitmap) extras.get("data");
                        imgPhoto.setImageBitmap(imageBitmap);
                    }
                }
        );
    }
}
