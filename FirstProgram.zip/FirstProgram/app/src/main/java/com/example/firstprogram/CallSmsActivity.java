package com.example.firstprogram;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.PhoneNumberUtils;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * CallSmsActivity
 * - btnDial: mở Dialer (không cần quyền)
 * - btnCall: gọi trực tiếp (CALL_PHONE) -> cần runtime permission
 * - btnSms: mở ứng dụng nhắn tin (ACTION_SENDTO) -> không cần quyền
 */
public class CallSmsActivity extends AppCompatActivity {

    private static final int REQ_CALL_PHONE = 1001;

    EditText edtPhone, edtSmsBody;
    Button btnDial, btnCall, btnSms;
    TextView tvInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call_sms);

        edtPhone = findViewById(R.id.edtPhone);
        edtSmsBody = findViewById(R.id.edtSmsBody);
        btnDial = findViewById(R.id.btnDial);
        btnCall = findViewById(R.id.btnCall);
        btnSms = findViewById(R.id.btnSms);
        tvInfo = findViewById(R.id.tvInfo);

        btnDial.setOnClickListener(v -> openDialer());
        btnCall.setOnClickListener(v -> callDirect());
        btnSms.setOnClickListener(v -> openSmsApp());
    }

    private String getPhone() {
        return edtPhone.getText().toString().trim();
    }

    private boolean isPhoneValid(String phone) {
        if (TextUtils.isEmpty(phone)) return false;
        return PhoneNumberUtils.isGlobalPhoneNumber(phone);
    }

    // --- Mở bàn phím gọi ---
    private void openDialer() {
        String phone = getPhone();
        if (!isPhoneValid(phone)) {
            toastAndInfo("Nhập số điện thoại hợp lệ để mở Dialer.");
            return;
        }
        Uri uri = Uri.parse("tel:" + phone);
        Intent intent = new Intent(Intent.ACTION_DIAL, uri);
        startActivity(intent);
    }

    // --- Gọi trực tiếp ---
    private void callDirect() {
        String phone = getPhone();
        if (!isPhoneValid(phone)) {
            toastAndInfo("Nhập số điện thoại hợp lệ để gọi.");
            return;
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CALL_PHONE}, REQ_CALL_PHONE);
            toastAndInfo("Vui lòng cấp quyền CALL_PHONE, sau đó bấm lại 'Call'.");
            return;
        }

        Uri uri = Uri.parse("tel:" + phone);
        Intent intent = new Intent(Intent.ACTION_CALL, uri);
        startActivity(intent);
    }

    // --- Mở ứng dụng nhắn tin ---
    private void openSmsApp() {
        String phone = getPhone();
        String body = edtSmsBody.getText().toString();

        if (!isPhoneValid(phone)) {
            toastAndInfo("Nhập số điện thoại hợp lệ để nhắn tin.");
            return;
        }

        Uri uri = Uri.parse("smsto:" + phone);
        Intent intent = new Intent(Intent.ACTION_SENDTO, uri);
        if (!TextUtils.isEmpty(body)) {
            intent.putExtra("sms_body", body);
        }

        try {
            startActivity(intent);
            toastAndInfo("Đã mở ứng dụng nhắn tin. Hãy chọn GỬI để hoàn tất.");
        } catch (Exception e) {
            toastAndInfo("Không thể mở ứng dụng nhắn tin trên thiết bị này.");
        }
    }

    private void toastAndInfo(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        tvInfo.setText(msg);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_CALL_PHONE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                toastAndInfo("Quyền CALL_PHONE đã được cấp. Nhấn lại 'Call' để gọi.");
            } else {
                toastAndInfo("Bạn chưa cấp quyền gọi điện trực tiếp.");
            }
        }
    }
}
