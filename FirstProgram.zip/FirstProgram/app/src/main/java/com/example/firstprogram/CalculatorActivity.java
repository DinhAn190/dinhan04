package com.example.firstprogram;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class CalculatorActivity extends AppCompatActivity {

    EditText txtX, txtY;
    TextView txtKQ;
    Button btnPlus, btnMinus, btnMul, btnDiv, btnMod;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);

        // Ánh xạ view
        txtX = findViewById(R.id.txtX);
        txtY = findViewById(R.id.txtY);
        txtKQ = findViewById(R.id.txtKQ);
        btnPlus = findViewById(R.id.btnPlus);
        btnMinus = findViewById(R.id.btnMinus);
        btnMul = findViewById(R.id.btnMul);
        btnDiv = findViewById(R.id.btnDiv);
        btnMod = findViewById(R.id.btnMod);

        // Gắn sự kiện click cho nút
        btnPlus.setOnClickListener(v -> tinhToan("+"));
        btnMinus.setOnClickListener(v -> tinhToan("-"));
        btnMul.setOnClickListener(v -> tinhToan("*"));
        btnDiv.setOnClickListener(v -> tinhToan("/"));
        btnMod.setOnClickListener(v -> tinhToan("%"));
    }

    private void tinhToan(String phepToan) {
        double x, y, kq = 0;
        try {
            x = Double.parseDouble(txtX.getText().toString());
            y = Double.parseDouble(txtY.getText().toString());
        } catch (Exception e) {
            txtKQ.setText("⚠️ Vui lòng nhập số hợp lệ!");
            return;
        }

        switch (phepToan) {
            case "+":
                kq = x + y;
                break;
            case "-":
                kq = x - y;
                break;
            case "*":
                kq = x * y;
                break;
            case "/":
                if (y == 0) {
                    txtKQ.setText("⚠️ Không chia được cho 0!");
                    return;
                }
                kq = x / y;
                break;
            case "%":
                if (y == 0) {
                    txtKQ.setText("⚠️ Không chia được cho 0!");
                    return;
                }
                kq = x % y;
                break;
        }

        txtKQ.setText("Kết quả: " + kq);
    }
}
