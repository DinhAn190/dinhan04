package com.example.lab3;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class StoryListActivity extends AppCompatActivity {

    RecyclerView rcv;
    ArrayList<StoryEntity> listStory = new ArrayList<>();
    String topic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_story_list);

        rcv = findViewById(R.id.rcvStory);

        topic = getIntent().getStringExtra("topic");

        loadStories();

        StoryAdapter adapter = new StoryAdapter(this, listStory);
        rcv.setLayoutManager(new LinearLayoutManager(this));
        rcv.setAdapter(adapter);
    }

    private void loadStories() {

        switch (topic) {

            case "Con gái":
                listStory.add(new StoryEntity(
                        "Khó hiểu thật",
                        "Một cô gái nói: ‘Em không bao giờ giận anh quá 5 phút...’\n" +
                                "Nhưng suốt 3 ngày không trả lời tin nhắn.\n" +
                                "Anh nhắn lại: ‘Vậy là 3 ngày này em chỉ đang... suy nghĩ 5 phút kéo dài thôi đúng không?’"
                ));

                listStory.add(new StoryEntity(
                        "Con gái thời nay",
                        "Ngày xưa con gái hay thẹn thùng, thấy ai nhìn là đỏ mặt cúi đầu.\n" +
                                "Bây giờ thẹn quá… đăng STT: ‘Buồn quá ai rủ đi chơi không?’ kèm 3 tấm hình xinh lung linh để câu like."
                ));

                listStory.add(new StoryEntity(
                        "Tính cách con gái",
                        "Con gái giận thì không nói, hỏi thì bảo ‘Không có gì’.\n" +
                                "Mà ‘Không có gì’ chính là ‘Có rất nhiều thứ đấy anh ạ!’.\n" +
                                "Và nhiệm vụ của con trai là phải đoán đúng… trong vòng 30 giây, nếu không sẽ sang level ‘Im lặng đáng sợ’."
                ));

                listStory.add(new StoryEntity(
                        "Nỗi sợ của con trai",
                        "Con trai không sợ ma, không sợ điểm thấp, không sợ deadline.\n" +
                                "Nhưng chỉ cần nghe con gái nói: ‘Em thấy hơi lạ nha!’ là biết sắp to chuyện rồi..."
                ));

                listStory.add(new StoryEntity(
                        "Khi con gái nói ‘Tùy anh’",
                        "Đừng tưởng là được quyền chọn.\n" +
                                "Vì dù bạn chọn gì đi nữa... thì bạn vẫn sai!"
                ));

                listStory.add(new StoryEntity(
                        "Thời tiết và con gái",
                        "Dự báo thời tiết: ‘Trời hôm nay nắng nhẹ, có mưa rào vài nơi.’\n" +
                                "Dự báo con gái: ‘Sáng vui, trưa dỗi, chiều im lặng, tối đăng story buồn.’"
                ));

                listStory.add(new StoryEntity(
                        "Khi yêu con gái",
                        "Con gái không cần người hoàn hảo, chỉ cần người hiểu được sự ‘không hoàn hảo’ của cô ấy.\n" +
                                "Nhưng mà… người hiểu được thì thường đã chạy mất tiêu vì sợ ‘tâm lý học nâng cao’."
                ));

                listStory.add(new StoryEntity(
                        "Logic của con gái",
                        "Anh: ‘Sao em nói lạnh mà vẫn bật quạt?’\n" +
                                "Cô ấy: ‘Tại nóng nhưng lạnh kiểu khác.’\n" +
                                "Anh: ‘???’ – và thế là anh bước sang một chiều không gian logic khác mà chỉ con gái hiểu."
                ));

                listStory.add(new StoryEntity(
                        "Ảnh đại diện",
                        "Con gái đổi ảnh đại diện không phải để làm đẹp.\n" +
                                "Đó là một tín hiệu ngầm: ‘Tôi đang buồn, ai đó hãy hỏi tôi đi!’.\n" +
                                "Nhưng nếu anh hỏi ‘Sao buồn vậy?’ thì câu trả lời sẽ là: ‘Ai nói em buồn?’."
                ));

                listStory.add(new StoryEntity(
                        "Con gái và mua sắm",
                        "Đi mua đồ với con gái là một cuộc phiêu lưu không lối thoát.\n" +
                                "Cô ấy thử 10 bộ, hỏi ý kiến 5 lần, rồi quay lại mua cái đầu tiên.\n" +
                                "Nhưng vui là ở chỗ: mỗi lần mua xong, cô ấy đều nói ‘Em không có gì để mặc hết!’."
                ));
                break;



            case "Cười 18+":
                listStory.add(new StoryEntity(
                        "Vova đi học",
                        "Cô giáo hỏi: ‘Vova! Em lấy ví dụ 1 con vật sống ở sa mạc?’\n" +
                                "Vova: ‘Con lạc đà ạ!’\n" +
                                "Cô: ‘Tốt! Thế con gì to bằng con lạc đà?’\n" +
                                "Vova: ‘Hai con lạc đà!’\n" +
                                "Cả lớp cười ồ, cô giáo cạn lời."
                ));

                listStory.add(new StoryEntity(
                        "Bài học về giới tính",
                        "Cô giáo hỏi: ‘Các em, ai có thể cho cô biết giới tính là gì?’\n" +
                                "Vova giơ tay: ‘Thưa cô, giới tính là bài học mà năm ngoái cô chưa dạy xong ạ!’\n" +
                                "Cô đỏ mặt: ‘Sao em biết?’\n" +
                                "Vova tỉnh bơ: ‘Vì em nghe bố mẹ bảo, bài đó người lớn còn đang thực hành mỗi tối!’"
                ));

                listStory.add(new StoryEntity(
                        "Giấc mơ kỳ lạ",
                        "Sáng dậy, Vova chạy đến khoe bố:\n" +
                                "– Bố ơi, tối qua con mơ thấy được cưới vợ!\n" +
                                "Bố cười: ‘Tốt quá! Rồi sao nữa?’\n" +
                                "Vova thở dài: ‘Rồi con mơ thấy mẹ con bước vào… và đám cưới chuyển thành lễ… hỏi tội!’"
                ));

                listStory.add(new StoryEntity(
                        "Khám sức khỏe",
                        "Bác sĩ: ‘Cậu hút thuốc không?’ – ‘Không ạ.’\n" +
                                "‘Uống rượu?’ – ‘Không luôn.’\n" +
                                "‘Thức khuya?’ – ‘Không.’\n" +
                                "‘Quan hệ?’ – ‘Dạ, cũng không ạ!’\n" +
                                "Bác sĩ nhìn Vova rồi nói: ‘Thế cậu sống để làm gì vậy?’"
                ));

                listStory.add(new StoryEntity(
                        "Con trai và con gái",
                        "Cô giáo hỏi: ‘Vova, tại sao con trai và con gái lại khác nhau?’\n" +
                                "Vova đáp: ‘Thưa cô, nếu giống nhau hết thì… chẳng ai muốn kết hôn nữa ạ!’"
                ));

                listStory.add(new StoryEntity(
                        "Kiểm tra IQ",
                        "Thầy giáo hỏi: ‘Nếu em có 10 cái bánh, em cho bạn 3 cái, em còn mấy cái?’\n" +
                                "Vova: ‘Còn 10 cái ạ!’\n" +
                                "Thầy: ‘Tại sao?’\n" +
                                "Vova: ‘Vì em nói “cho” thôi, chứ chưa chắc em đã đưa!’"
                ));

                listStory.add(new StoryEntity(
                        "Cách chữa ngáy",
                        "Một cô gái than với bác sĩ:\n" +
                                "– Bác sĩ ơi, chồng em ngáy to quá, không ngủ nổi!\n" +
                                "Bác sĩ: ‘Trước khi ngủ, cô nên nói chuyện nhẹ nhàng, tình cảm, làm anh ấy vui.’\n" +
                                "Cô hỏi lại: ‘Rồi anh ấy sẽ không ngáy nữa hả bác sĩ?’\n" +
                                "Bác sĩ đáp: ‘Không, nhưng cô sẽ mệt đến mức không nghe thấy tiếng ngáy nữa!’"
                ));

                listStory.add(new StoryEntity(
                        "Thầy giáo hỏi Vova",
                        "Thầy: ‘Vova, em biết thế nào là “người đàn ông trưởng thành” không?’\n" +
                                "Vova: ‘Thưa thầy, là người biết nhận lỗi dù chưa làm gì sai, chỉ để yên nhà ạ!’"
                ));

                listStory.add(new StoryEntity(
                        "Bí quyết hạnh phúc",
                        "Cô giáo hỏi học sinh:\n" +
                                "– Theo các em, bí quyết để hôn nhân hạnh phúc là gì?\n" +
                                "Vova: ‘Là đừng cố gắng hiểu phụ nữ, thưa cô!’\n" +
                                "Cô: ‘Em nghĩ thế à?’\n" +
                                "Vova: ‘Không ạ, em nghe bố em nói trong lúc… mẹ em không ở nhà!’"
                ));

                listStory.add(new StoryEntity(
                        "Câu hỏi khó",
                        "Trong giờ Sinh học, cô hỏi: ‘Tại sao khi yêu, tim đập nhanh?’\n" +
                                "Vova đáp: ‘Thưa cô, vì lúc đó bộ não tạm ngưng hoạt động ạ!’"
                ));

                break;



            case "Vova":
                listStory.add(new StoryEntity(
                        "Vợ là số 1",
                        "Anh chồng bảo: ‘Em là số 1 trong lòng anh.’\n" +
                                "Vợ: ‘Còn số 2?’\n" +
                                "Chồng: ‘Là số tài khoản ngân hàng... nhưng anh quên mật khẩu rồi.’"
                ));

                listStory.add(new StoryEntity(
                        "Cãi nhau",
                        "Vợ: ‘Anh chưa bao giờ nghe em nói hết câu!’\n" +
                                "Chồng: ‘Ừ, đúng rồi. Tại em nói dài quá.’"
                ));

                listStory.add(new StoryEntity(
                        "Đi nhậu",
                        "Vợ: ‘Anh đi nhậu với ai?’\n" +
                                "Chồng: ‘Với đối tác.’\n" +
                                "Vợ: ‘Anh làm gì có công ty mà đối tác!’\n" +
                                "Chồng: ‘Thì là đối tác uống thôi!’"
                ));

                listStory.add(new StoryEntity(
                        "Tặng quà",
                        "Vợ: ‘Anh ơi, ngày 8/3 anh tặng em gì đây?’\n" +
                                "Chồng: ‘Anh tặng em cả thế giới này!’\n" +
                                "Vợ: ‘Vậy cái túi em thích nằm ở đâu trong thế giới đó?’"
                ));

                listStory.add(new StoryEntity(
                        "Khi vợ im lặng",
                        "Vova hỏi bố: ‘Bố ơi, tại sao mẹ im lặng suốt vậy?’\n" +
                                "Bố thở dài: ‘Con ạ, đó là giai đoạn nguy hiểm nhất trong hôn nhân. Khi mẹ con im, nghĩa là… bão sắp đến!’"
                ));

                listStory.add(new StoryEntity(
                        "Đi siêu thị",
                        "Vợ: ‘Anh có thấy người ta nhìn em không?’\n" +
                                "Chồng: ‘Có, họ nhìn anh – người đàn ông dũng cảm đi mua sắm 3 tiếng không than nửa lời!’"
                ));

                listStory.add(new StoryEntity(
                        "Vova đi học",
                        "Cô giáo hỏi: ‘Vova, em cho cô ví dụ về một phép màu?’\n" +
                                "Vova đáp: ‘Thưa cô, phép màu là khi mẹ em giận, mà bố em vẫn sống tới hôm nay ạ!’"
                ));

                listStory.add(new StoryEntity(
                        "Tình yêu chân thành",
                        "Vova nói với bạn: ‘Tớ yêu cô ấy vì tâm hồn cô ấy!’\n" +
                                "Bạn hỏi: ‘Thế tớ thấy cậu toàn nhìn chân cô ấy?’\n" +
                                "Vova: ‘Thì tớ đang tìm tâm hồn ở đâu thôi!’"
                ));

                listStory.add(new StoryEntity(
                        "Kiểm tra sức khỏe",
                        "Bác sĩ hỏi: ‘Anh có hay bị đau đầu không?’\n" +
                                "Vova: ‘Chỉ khi vợ nói câu “Anh rảnh không, em hỏi tí thôi!”’"
                ));

                listStory.add(new StoryEntity(
                        "Vova và Toán học",
                        "Cô giáo: ‘Vova, 1 cộng 1 bằng mấy?’\n" +
                                "Vova: ‘Tùy hoàn cảnh ạ.’\n" +
                                "Cô ngạc nhiên: ‘Là sao?’\n" +
                                "Vova: ‘Nếu là tiền thì bằng 10, còn nếu là lỗi thì bằng 100 lần xin lỗi!’"
                ));

                listStory.add(new StoryEntity(
                        "Vova hỏi bố",
                        "Vova: ‘Bố ơi, sao người ta nói hôn nhân là nghĩa địa của tình yêu?’\n" +
                                "Bố: ‘Vì con trai nào cũng nghĩ mình là anh hùng cho đến khi gặp… mẹ con.’"
                ));

                listStory.add(new StoryEntity(
                        "Học ngoại ngữ",
                        "Vova: ‘Bố ơi, học tiếng Anh khó không?’\n" +
                                "Bố: ‘Không bằng học cách hiểu mẹ con đâu con!’"
                ));

                listStory.add(new StoryEntity(
                        "Vova tỏ tình",
                        "Vova: ‘Em ơi, em đẹp như ánh trăng!’\n" +
                                "Cô gái: ‘Thật hả?’\n" +
                                "Vova: ‘Ừ, vì chỉ dám nhìn thôi, lại không dám chạm!’"
                ));

                break;



            case "Trạng Quỳnh":
                listStory.add(new StoryEntity(
                        "Triết lý cà phê",
                        "Cuộc sống giống ly cà phê: đắng, nhưng thơm.\n" +
                                "Quan trọng là ai pha và uống với ai."
                ));

                listStory.add(new StoryEntity(
                        "Đi làm",
                        "Đi làm để kiếm tiền.\n" +
                                "Kiếm tiền để sống.\n" +
                                "Nhưng đi làm nhiều quá… lại không có thời gian sống."
                ));

                listStory.add(new StoryEntity(
                        "Trạng đi chợ",
                        "Một bà bán hàng hỏi: ‘Trạng mua gì mà cứ ngắm mãi thế?’\n" +
                                "Trạng đáp: ‘Tôi đang chọn xem cái nào rẻ hơn – món hàng hay lời nói của bà!’"
                ));

                listStory.add(new StoryEntity(
                        "Thưởng Tết",
                        "Vua hỏi Quỳnh: ‘Theo khanh, nên thưởng người chăm chỉ thế nào?’\n" +
                                "Quỳnh đáp: ‘Thưởng tiền.’\n" +
                                "‘Còn người lười?’ – ‘Thưởng việc, cho họ làm tiếp để… khỏi rảnh nói linh tinh.’"
                ));

                listStory.add(new StoryEntity(
                        "Thi nói thật",
                        "Vua ra lệnh: ‘Ai nói thật sẽ được thưởng.’\n" +
                                "Quỳnh bước ra: ‘Thần nói thật là… thần chẳng tin bệ hạ sẽ thưởng!’\n" +
                                "Vua cười: ‘Thưởng ngay, vì khanh dám nói đúng lòng trẫm!’"
                ));

                listStory.add(new StoryEntity(
                        "Ăn tiệc vua",
                        "Trong bữa tiệc, ai cũng cúi đầu ăn nhỏ nhẹ.\n" +
                                "Riêng Quỳnh ăn ngon lành.\n" +
                                "Vua hỏi: ‘Sao khanh không giữ ý?’\n" +
                                "Quỳnh đáp: ‘Thần đói thì ăn, đâu dám giữ ý với cái bụng!’"
                ));

                listStory.add(new StoryEntity(
                        "Trạng và quan tham",
                        "Quan huyện khoe: ‘Ta thanh liêm nhất vùng!’\n" +
                                "Quỳnh cười: ‘Vâng, liêm đến mức tiền dân cúng cũng không kịp chảy ra ngoài.’"
                ));

                listStory.add(new StoryEntity(
                        "Trạng đi học",
                        "Thầy hỏi: ‘Nếu có người nói dối con, con làm gì?’\n" +
                                "Quỳnh đáp: ‘Thưa thầy, con sẽ hỏi lại để họ tự nói dối thêm cho lộ hết ạ!’"
                ));

                listStory.add(new StoryEntity(
                        "Chọn vợ",
                        "Bạn hỏi: ‘Trạng chọn vợ theo tiêu chí gì?’\n" +
                                "Trạng đáp: ‘Không chọn người hoàn hảo, chỉ chọn người biết… tha lỗi cho sự ngu của mình.’"
                ));

                listStory.add(new StoryEntity(
                        "Trạng và Facebook",
                        "Có người hỏi: ‘Sao Trạng không đăng gì lên Facebook?’\n" +
                                "Trạng đáp: ‘Ngày xưa ta dạy đời, giờ mạng dạy lại ta, nên ta im cho yên.’"
                ));

                listStory.add(new StoryEntity(
                        "Trạng và tiền",
                        "Vua hỏi: ‘Tiền có quan trọng không?’\n" +
                                "Quỳnh: ‘Dạ, không có tiền thì khó sống, nhưng có nhiều tiền mà ngu thì sống khó hơn!’"
                ));

                listStory.add(new StoryEntity(
                        "Trạng đi khám",
                        "Bác sĩ hỏi: ‘Ông có bị stress không?’\n" +
                                "Trạng đáp: ‘Không, tôi stress thay cho người khác rồi – ai thấy tôi cũng cười mà!’"
                ));

                listStory.add(new StoryEntity(
                        "Trạng thời hiện đại",
                        "Nếu Trạng Quỳnh sống thời nay, chắc đã làm TikToker.\n" +
                                "Mỗi clip chỉ 30 giây, nhưng khiến cả triều đình… cãi nhau nguyên ngày!"
                ));

                break;

        }
    }
}


