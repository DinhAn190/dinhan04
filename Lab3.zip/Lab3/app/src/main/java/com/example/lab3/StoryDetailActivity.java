package com.example.lab3;

import android.os.Bundle;
import android.view.MotionEvent;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class StoryDetailActivity extends AppCompatActivity {

    TextView tv;
    ArrayList<StoryEntity> list;
    int index;

    float x1, x2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_story_detail);

        tv = findViewById(R.id.tvContent);

        list = getIntent().getParcelableArrayListExtra("list");
        index = getIntent().getIntExtra("index", 0);

        showStory();

        tv.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    x1 = event.getX();
                    return true;
                case MotionEvent.ACTION_UP:
                    x2 = event.getX();
                    if (x1 - x2 > 150) nextStory();
                    if (x2 - x1 > 150) prevStory();
                    return true;
            }
            return false;
        });
    }

    private void showStory() {
        tv.setText(list.get(index).content);
    }

    private void nextStory() {
        if (index < list.size() - 1) {
            index++;
            showStory();
        }
    }

    private void prevStory() {
        if (index > 0) {
            index--;
            showStory();
        }
    }
}
