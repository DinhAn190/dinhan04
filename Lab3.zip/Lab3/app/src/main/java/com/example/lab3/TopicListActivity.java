package com.example.lab3;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class TopicListActivity extends AppCompatActivity {

    RecyclerView rcv;
    ArrayList<String> listTopic = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_topic_list);

        rcv = findViewById(R.id.rcvTopic);

        listTopic.add("Con gái");
        listTopic.add("Cười 18+");
        listTopic.add("Trạng Quỳnh");
        listTopic.add("Vova");

        TopicAdapter adapter = new TopicAdapter(this, listTopic);

        rcv.setLayoutManager(new LinearLayoutManager(this));
        rcv.setAdapter(adapter);
    }
}
