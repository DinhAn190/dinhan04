package com.example.lab3;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class StoryAdapter extends RecyclerView.Adapter<StoryAdapter.StoryHolder> {

    ArrayList<StoryEntity> list;
    Context context;

    public StoryAdapter(Context ctx, ArrayList<StoryEntity> list) {
        this.context = ctx;
        this.list = list;
    }

    @NonNull
    @Override
    public StoryHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_story, parent, false);
        return new StoryHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull StoryHolder holder, int position) {
        StoryEntity s = list.get(position);

        holder.tvTitle.setText(s.title);
        holder.tvShort.setText(s.content.substring(0, 50) + "...");

        holder.itemView.setOnClickListener(v -> {
            Intent i = new Intent(context, StoryDetailActivity.class);
            i.putParcelableArrayListExtra("list", list);
            i.putExtra("index", position);
            context.startActivity(i);
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    static class StoryHolder extends RecyclerView.ViewHolder {
        TextView tvTitle, tvShort;

        public StoryHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvStoryTitle);
            tvShort = itemView.findViewById(R.id.tvShortDesc);
        }
    }
}

