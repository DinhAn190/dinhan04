package com.example.lab3;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Mặc định chạy splash trước
        goToSplashScreen();
    }


    // ----------------------------------------------------
    // ✅ HÀM ĐI TỚI SPLASH
    // ----------------------------------------------------
    public void goToSplashScreen() {
        Intent i = new Intent(MainActivity.this, SplashActivity.class);
        startActivity(i);
    }


    // ----------------------------------------------------
    // ✅ HÀM ĐI TỚI DANH SÁCH CHỦ ĐỀ
    // ----------------------------------------------------
    public void goToTopicScreen() {
        Intent i = new Intent(MainActivity.this, TopicListActivity.class);
        startActivity(i);
    }


    // ----------------------------------------------------
    // ✅ HÀM ĐI TỚI DANH SÁCH TRUYỆN TRONG CHỦ ĐỀ
    // ----------------------------------------------------
    public void goToStoryListScreen(String topicName) {
        Intent i = new Intent(MainActivity.this, StoryListActivity.class);
        i.putExtra("topic", topicName);
        startActivity(i);
    }


    // ----------------------------------------------------
    // ✅ HÀM ĐI TỚI MÀN HÌNH XEM TRUYỆN
    // ----------------------------------------------------
    public void goToStoryDetailScreen(ArrayList<StoryEntity> listStory, int index) {
        Intent i = new Intent(MainActivity.this, StoryDetailActivity.class);
        i.putParcelableArrayListExtra("list", listStory);
        i.putExtra("index", index);
        startActivity(i);
    }
}
