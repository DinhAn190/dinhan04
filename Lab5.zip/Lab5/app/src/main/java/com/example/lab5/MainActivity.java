package com.example.lab5;

import android.os.Bundle;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private ImageView ivAnimal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
    }

    private void initViews() {
        // Animation
        ivAnimal = findViewById(R.id.iv_animal);
        findViewById(R.id.bt_alpha).setOnClickListener(this);
        findViewById(R.id.bt_rotate).setOnClickListener(this);
        findViewById(R.id.bt_scale).setOnClickListener(this);
        findViewById(R.id.bt_trans).setOnClickListener(this);

        // QuickCall
        initQuickCallClick(R.id.fr_mom);
        initQuickCallClick(R.id.fr_dad);
        initQuickCallClick(R.id.fr_crush);
        initQuickCallClick(R.id.fr_best_friend);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.bt_alpha) {
            ivAnimal.startAnimation(AnimationUtils.loadAnimation(this, R.anim.alpha));
        } else if (id == R.id.bt_rotate) {
            ivAnimal.startAnimation(AnimationUtils.loadAnimation(this, R.anim.rotate));
        } else if (id == R.id.bt_scale) {
            ivAnimal.startAnimation(AnimationUtils.loadAnimation(this, R.anim.scale));
        } else if (id == R.id.bt_trans) {
            ivAnimal.startAnimation(AnimationUtils.loadAnimation(this, R.anim.translate));
        }
    }


    private void initQuickCallClick(int frameId) {
        FrameLayout frame = findViewById(frameId);
        frame.setOnClickListener(v -> {
            String phone = (String) v.getTag();
            Toast.makeText(MainActivity.this, "Call " + phone, Toast.LENGTH_SHORT).show();
        });
    }
}
