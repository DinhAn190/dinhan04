package com.example.lab4;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MenuActivity extends AppCompatActivity {

    private static final int[] ID_DRAWABLES = {
            R.drawable.ic_mess, R.drawable.ic_flight, R.drawable.ic_hospital,
            R.drawable.ic_hotel, R.drawable.ic_restaurant, R.drawable.ic_coctail,
            R.drawable.ic_store, R.drawable.ic_work, R.drawable.ic_time,
            R.drawable.ic_education, R.drawable.ic_movie
    };
    private static final int[] ID_TEXTS = {
            R.string.txt_mess, R.string.txt_flight, R.string.txt_hospital,
            R.string.txt_hotel, R.string.txt_restaurant, R.string.txt_coctail,
            R.string.txt_store, R.string.txt_work, R.string.txt_time,
            R.string.txt_education, R.string.txt_movie
    };

    Map<String, List<String>> vocabularyMap = new HashMap<>();
    LinearLayout lnMain;
    Button btnRandomIcons;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        lnMain = findViewById(R.id.lnMain);
        btnRandomIcons = findViewById(R.id.btnRandomIcons);

        // Sample vocabulary
        vocabularyMap.put(getString(R.string.txt_mess), Arrays.asList("Hello", "Goodbye", "Thanks"));
        vocabularyMap.put(getString(R.string.txt_flight), Arrays.asList("Ticket", "Airport", "Hotel"));

        // Lấy và hiển thị tất cả icon lần đầu
        showIcons(ID_DRAWABLES, ID_TEXTS);

        // Bấm nút Random Icons
        btnRandomIcons.setOnClickListener(v -> {
            // Random 10 icon
            List<Integer> drawableList = new ArrayList<>();
            List<Integer> textList = new ArrayList<>();
            for (int i = 0; i < ID_DRAWABLES.length; i++) {
                drawableList.add(ID_DRAWABLES[i]);
                textList.add(ID_TEXTS[i]);
            }

            // Trộn danh sách
            Collections.shuffle(drawableList);
            Collections.shuffle(textList);

            // Lấy 10 phần tử đầu
            int[] randomDrawables = new int[10];
            int[] randomTexts = new int[10];
            for (int i = 0; i < 10; i++) {
                randomDrawables[i] = drawableList.get(i);
                randomTexts[i] = textList.get(i);
            }

            // Hiển thị
            showIcons(randomDrawables, randomTexts);
        });
    }

    private void showIcons(int[] drawables, int[] texts) {
        lnMain.removeAllViews();
        for (int i = 0; i < drawables.length; i++) {
            View v = LayoutInflater.from(this).inflate(R.layout.item_topic, null);
            ImageView ivTopic = v.findViewById(R.id.ivTopic);
            TextView tvTopic = v.findViewById(R.id.tvTopic);

            ivTopic.setImageResource(drawables[i]);
            tvTopic.setText(texts[i]);

            int index = i;
            tvTopic.setOnClickListener(view -> {
                String topic = getString(texts[index]);
                List<String> words = vocabularyMap.get(topic);
                if (words == null) words = Arrays.asList();
                Toast.makeText(this, "Chủ đề " + topic + " có " + words.size() + " từ vựng", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(MenuActivity.this, TopicActivity.class);
                intent.putStringArrayListExtra("words", new ArrayList<>(words));
                intent.putExtra("topic", topic);
                startActivity(intent);
            });

            lnMain.addView(v);
        }
    }
}
