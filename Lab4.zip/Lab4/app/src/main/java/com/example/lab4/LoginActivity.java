package com.example.lab4;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    EditText edtEmail, edtPassword;
    TextView tvLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        edtEmail = findViewById(R.id.edtEmail);
        edtPassword = findViewById(R.id.edtPassword);
        tvLogin = findViewById(R.id.tvLogin);

        tvLogin.setOnClickListener(v -> {
            String email = edtEmail.getText().toString();
            String pass = edtPassword.getText().toString();

            // Inflate layout custom Toast
            View layout = LayoutInflater.from(this).inflate(R.layout.toast_layout, findViewById(android.R.id.content), false);
            TextView tvToastText = layout.findViewById(R.id.tvToastText);
            tvToastText.setText("Bạn đã đăng nhập thành công với email: " + email + " và mật khẩu: " + pass);

            // Tạo và hiển thị Toast
            Toast toast = new Toast(this);
            toast.setView(layout);
            toast.setDuration(Toast.LENGTH_LONG);
            toast.setGravity(android.view.Gravity.CENTER, 0, 0); // Hiển thị ở giữa màn hình
            toast.show();

            // Mở MenuActivity
            Intent intent = new Intent(LoginActivity.this, MenuActivity.class);
            startActivity(intent);
        });


    }
}
